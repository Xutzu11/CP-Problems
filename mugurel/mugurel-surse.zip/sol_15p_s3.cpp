#include <bits/stdc++.h>

using namespace std;

ifstream f("mugurel.in");
ofstream g("mugurel.out");

///Solutie 15p: Ignat Alex-Matei
///Subtask 3: Toate gramezile au acelasi numar de kilograme

int n,m;
int k,a,b,c;
int fructe[1005][1005][3];
int sir[1000005];
int maxkgport, maxkgban, maxkgmixt;
char tipuri[1000005];
int nrcutii;
int minst[1000005], mindr[1000005], maxst[1000005], maxdr[1000005];

void citire() {
    f >> n >> m;
    f >> k >> a >> b >> c;
    for (int i=1;i<=n;i++) {
        for (int j=1;j<=m;j++) {
            f >> fructe[i][j][0];
            fructe[i][j][2] += fructe[i][j][0];
        }
    }
    for (int i=1;i<=n;i++) {
        for (int j=1;j<=m;j++) {
            f >> fructe[i][j][1];
            fructe[i][j][2] += fructe[i][j][1];
        }
    }
}

int main()
{
    citire();
    int x = k/n;
    int nr_gr = 0;
    if (m%x == 0) {
        nr_gr = m/x;
    }
    else nr_gr = m/x + 1;
    int method = 0;
    if (1LL*a*nr_gr*fructe[1][1][0]+1LL*b*nr_gr*fructe[1][1][0] < 1LL*c*nr_gr*2*fructe[1][1][0]) {
        maxkgport = maxkgban = nr_gr*fructe[1][1][0];
        g << 1LL*a*nr_gr*fructe[1][1][0]+1LL*b*nr_gr*fructe[1][1][0] << '\n';
        method = 1;
    }
    else {
        maxkgmixt = nr_gr*2*fructe[1][1][0];
        g << 1LL*c*nr_gr*2*fructe[1][1][0] << '\n';
        method = 2;
    }
    for (int i=1;i<=n;i++) {
        int kgport = 0, kgban = 0, kgmixt = 0;
        for (int j=1;j<=m;j++) {
            if (method==1) {
                kgport += fructe[i][j][0];
                kgban += fructe[i][j][1];
                if (kgport==maxkgport || j==m) {
                    sir[++nrcutii] = kgport; tipuri[nrcutii] = 'P';
                    sir[++nrcutii] = kgban; tipuri[nrcutii] = 'B';
                    kgport = kgban = 0;
                }
            }
            else {
                kgmixt += fructe[i][j][2];
                if (kgmixt == maxkgmixt || j == m) {
                    sir[++nrcutii] = kgmixt; tipuri[nrcutii] = 'M';
                    kgmixt = 0;
                }
            }
        }
    }
    g << nrcutii << '\n';
    for (int i=1;i<=nrcutii;i++) {
        g << sir[i] << " " << tipuri[i] << '\n';
    }
    int mindisc = INT_MAX;
    minst[1] = sir[1]; maxst[1] = sir[1];
    maxdr[nrcutii] = sir[nrcutii]; mindr[nrcutii] = sir[nrcutii];
    for (int i=2;i<=nrcutii;i++) {
        minst[i] = min(minst[i-1], sir[i]);
        maxst[i] = max(maxst[i-1], sir[i]);
    }
    for (int i=nrcutii-1;i>=1;i--) {
        mindr[i] = min(mindr[i+1], sir[i]);
        maxdr[i] = max(maxdr[i+1], sir[i]);
    }
    for (int i=1;i<nrcutii;i++) {
        mindisc = min(mindisc, maxst[i]-minst[i]+maxdr[i+1]-mindr[i+1]);
    }
    g << mindisc;
    return 0;
}
