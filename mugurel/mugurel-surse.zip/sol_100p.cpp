#include <bits/stdc++.h>
using namespace std;

ifstream f("mugurel.in");
ofstream g("mugurel.out");

///Solutie 100p: Ignat Alex-Matei

int n,m;
int k;
int a,b,c;
int fruits[1005][1005][3];
int minport, minban, minmixt;
int maxport, maxban, maxmixt;
int sport, sban, smixt;
int kg, kgport, kgban, kgmixt, nboxes;
int minkgport, minkgban, minkgmixt;
int boxes[2000005];
int minst[2000005], maxst[2000005], mindr[2000005], maxdr[2000005];
int minbox, maxbox;
int mindisc, method;
char tipuri[2000005];

void citire() {
    f >> n >> m;
    f >> k >> a >> b >> c;
    for (int i=1;i<=n;i++) {
        sport = 0;
        for (int j=1;j<=m;j++) {
            f >> fruits[i][j][0]; /// fruits[][][0] -> matricea gramezilor de portocale
            sport += fruits[i][j][0];
            minport = max(minport, fruits[i][j][0]); ///retinem gramada minima de portocale
            fruits[i][j][2] += fruits[i][j][0]; /// fruits[][][2] -> matricea mixta (suma portocale + banane)
        }
        maxport = max(maxport, sport); ///retinem gramada maxima de portocale
    }
    for (int i=1;i<=n;i++) {
        sban = 0; smixt = 0;
        for (int j=1;j<=m;j++) {
            f >> fruits[i][j][1]; /// fruits[][][1] -> matricea gramezilor de banane
            fruits[i][j][2] += fruits[i][j][1];
            sban += fruits[i][j][1]; smixt += fruits[i][j][2]; /// fruits[][][2] -> matricea mixta (suma portocale + banane)
            minban = max(minban, fruits[i][j][1]); ///retinem gramada minima de banane
            minmixt = max(minmixt, fruits[i][j][2]); ///retinem gramada minima mixta
        }
        maxban = max(maxban, sban); ///retinem gramada maxima de banane
        maxmixt = max(maxmixt, smixt); ///retinem gramada maxima mixta
    }
}

int cb(long long st, long long dr, int ind) {
    /// Vom face o cautare binara a cutiei necesare
    /// Avem nevoie de trei cautari binare: pentru portocale, pentru banane, pentru mixt
    /// De aceea, este mai simplu de implementat o singura functie pentru toate cele trei matrice
    while (st!=dr) {
        nboxes = 0;
        long long mij = (st+dr)/2; /// Facem o simulare, in care presupunem ca toate cele k cutii au 'mij' kg
        for (int i=1;i<=n;i++) {
            kg = 0;
            for (int j=1;j<=m;j++) {
                if (kg + fruits[i][j][ind] <= mij) {
                    kg += fruits[i][j][ind]; /// Adaugam gramada in cutie daca nu depasim capacitatea
                }
                else {
                    kg = fruits[i][j][ind]; /// Altfel, inchidem cutie curenta si incepem una noua, in care punem gramada curenta
                    nboxes++;
                }
            }
            nboxes++; /// La final de zi, inchidem cutia ramasa deschisa
        }
        if (nboxes<=k) {
            dr = mij; /// Daca este o solutie corecta, vom cauta un numar mai mic sau egal de kg
        }
        else {
            st = mij+1; /// Altfel, avem nevoie de cutii cu o capacitate mai mare
        }
    }
    return st;
}

void creare_cutii() {
    /// Dupa stabilirea kilogramelor minime, si a metodei folosite, ne vom crea sirul de cutii
    /// Facem aceeasi simulare de la cautarea binara, dar cu capacitatile cutiilor stabilite
    /// Lucram in paralel cu ambele metode, insa luam in considerare doar una (pentru a nu implementa doua functii diferite)
    nboxes = 0;
    for (int i=1;i<=n;i++) {
        kgport = kgban = kgmixt = 0;
        for (int j=1;j<=m;j++) {
            if (method==1) {
                if (kgport + fruits[i][j][0] <= minkgport) {
                    kgport += fruits[i][j][0];
                }
                else {
                    boxes[++nboxes] = kgport;
                    tipuri[nboxes] = 'P';
                    kgport = fruits[i][j][0];
                }
                if (kgban + fruits[i][j][1] <= minkgban) {
                    kgban += fruits[i][j][1];
                }
                else {
                    boxes[++nboxes] = kgban;
                    tipuri[nboxes] = 'B';
                    kgban = fruits[i][j][1];
                }
            }
            else {
                if (kgmixt + fruits[i][j][2] <= minkgmixt) {
                    kgmixt += fruits[i][j][2];
                }
                else {
                    boxes[++nboxes] = kgmixt;
                    tipuri[nboxes] = 'M';
                    kgmixt = fruits[i][j][2];
                }
            }
        }
        if (method==1) {
            boxes[++nboxes] = kgport;
            tipuri[nboxes] = 'P';
            boxes[++nboxes] = kgban;
            tipuri[nboxes] = 'B';
        }
        else {
            boxes[++nboxes] = kgmixt;
            tipuri[nboxes] = 'M';
        }
    }
}

int main()
{
    citire();
    minkgport = cb(minport, maxport, 0);
    minkgban = cb(minban, maxban, 1);
    minkgmixt = cb(minmixt, maxmixt, 2);
    /// Suma cheltuita este stabilita printr-o formula simpla:
    /// Minim (Capacitate Cutie Portocale * A + Capacitate Cutie Banane * B, Capacitate Cutie Mixta * C)
    if (1LL*minkgport*a+1LL*minkgban*b <= 1LL*minkgmixt*c) {
        g << 1LL*minkgport*a+1LL*minkgban*b << '\n';
        minbox = -1; maxbox = max(minkgport, minkgban) + 1;
        method = 1;
    }
    else {
        g << 1LL*minkgmixt*c << '\n';
        minbox = -1; maxbox = minkgmixt + 1;
        method = 2;
    }
    creare_cutii();
    /// Pentru cea de-a doua parte, creem urmatorii 4 vectori:
    /// minst[i] -> cutia minima din sirul 1...i
    /// mindr[i] -> cutia minima din sirul i...n
    /// maxst[i] -> cutia maxima din sirul 1...i
    /// maxdr[i] -> cutia maxima din sirul i...n
    minst[0] = mindr[nboxes+1] = maxbox; /// Initializarea pentru formula recurenta
    maxst[0] = maxdr[nboxes+1] = minbox; /// Initializarea pentru formula recurenta
    for (int i=1;i<=nboxes;i++) {
        minst[i] = min(minst[i-1], boxes[i]);
        maxst[i] = max(maxst[i-1], boxes[i]);
    }
    for (int i=nboxes;i>=1;i--) {
        mindr[i] = min(mindr[i+1], boxes[i]);
        maxdr[i] = max(maxdr[i+1], boxes[i]);
    }
    mindisc = INT_MAX; /// Discreptanta minima, initial inf
    for (int i=1;i<nboxes;i++) {
        /// Consideram ca impartim sirul in doua siruri 1...i si i+1...n
        /// Atunci, putem afla cu ajutorul celor 4 siruri discrepanta pentru aceasta impartire
        mindisc = min(mindisc,maxst[i]-minst[i]+maxdr[i+1]-mindr[i+1]);
    }
    g << nboxes << '\n';
    for (int i=1;i<=nboxes;i++) {
        g << boxes[i] << " " << tipuri[i] << '\n';
    }
    g << mindisc;
    return 0;
}
