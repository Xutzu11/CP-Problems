#include <bits/stdc++.h>

using namespace std;

const int VMAX = 1e6;
const int NMAX = 1e3;
const int MMAX = 1e3;
const int CAP_MAX = 1e9;

int get_min_boxes_for_matrix(const vector<vector<int> > &v, int cap) {
  int ans = 0;
  for(int i = 1;i < (int)v.size();i++){
    int so_far = 0;
    for(int j = 1;j < (int)v[i].size();j++){
      if(v[i][j] > cap) {
        return NMAX * MMAX + 1;
      }
      if(v[i][j] + so_far > cap) {
        so_far = 0;
        ans++;
      }
      so_far += v[i][j];
    }
    ans += 1;
  }
  return ans;
}

int get_cap_for_matrix(const vector<vector<int> >& v, int k) {
  int l = 0;
  int r = CAP_MAX + 1;

  while(r - l > 1) {
    int mid = (l + r) / 2;

    if(get_min_boxes_for_matrix(v, mid) <= k) {
      r = mid;
    } else {
      l = mid;
    }
  }

  return r;
}

int main() {
  freopen("mugurel.in", "r" , stdin);
  freopen("mugurel.out", "w" , stdout);

  int n, m;
  
  scanf("%d %d", &n, &m);
  assert(1 <= n && n <= NMAX);
  assert(1 <= m && m <= NMAX);

  int k, a, b, c;

  scanf("%d %d %d %d", &k, &a, &b, &c);
  assert(n <= k && k <= n * m);
  assert(1 <= a && a <= VMAX);
  assert(1 <= b && b <= VMAX);
  assert(1 <= c && c <= VMAX);

  vector<vector<int> > fst(n + 1, vector<int>(m + 1, 0));
  vector<vector<int> > snd(n + 1, vector<int>(m + 1, 0));
  vector<vector<int> > combined(n + 1, vector<int>(m + 1, 0));

  for(int i = 1;i <= n;i++) {
    for(int j = 1;j <= m;j++) {
      scanf("%d", &fst[i][j]);
      assert(1 <= fst[i][j] && fst[i][j] <= VMAX);

    }
  }
  
  for(int i = 1;i <= n;i++) {
    for(int j = 1;j <= m;j++) {
      scanf("%d", &snd[i][j]);
      assert(1 <= snd[i][j] && snd[i][j] <= VMAX);
    }
  }

  for(int i = 1;i <= n;i++) {
    for(int j = 1;j <= m;j++) {
      combined[i][j] = fst[i][j] + snd[i][j];
    }
  }

  int c_a = get_cap_for_matrix(fst, k);
  int c_b = get_cap_for_matrix(snd, k);
  int c_m = get_cap_for_matrix(combined, k);

  vector<pair<int, char>> crates;

  if(1LL * a * c_a + 1LL * b * c_b <= 1LL * c * c_m) {
    printf("%lld\n", 1LL * a * c_a + 1LL * b * c_b);  
    for(int i = 1;i <= n;i++) {
      int current_a = 0, current_b = 0;
      for(int j = 1;j <= m;j++){
        if(current_a + fst[i][j] > c_a) {
            crates.push_back({current_a, 'P'});
            current_a = 0;
        } 
        current_a += fst[i][j];
        if(current_b + snd[i][j] > c_b) {
            crates.push_back({current_b, 'B'});
            current_b = 0;
        } 
        current_b += snd[i][j];
      }
      crates.push_back({current_a, 'P'});
      crates.push_back({current_b, 'B'});
    }
  } else {
    printf("%lld\n", 1LL * c * c_m);  
    for(int i = 1;i <= n;i++) {
      int current = 0;
      for(int j = 1;j <= m;j++){
        if(current + combined[i][j] > c_m) {
            crates.push_back({current, 'M'});
            current = 0;
        } 
        current += combined[i][j];
      }
      crates.push_back({current, 'M'});
    }
  }

  printf("%d\n", (int)crates.size());

  for(auto it:crates) {
    printf("%d %c\n", it.first, it.second);
  }

  vector<int> pref_max(crates.size(), -CAP_MAX);
  vector<int> pref_min(crates.size(), CAP_MAX);
  vector<int> suff_max(crates.size(), -CAP_MAX);
  vector<int> suff_min(crates.size(), CAP_MAX);

  for(int i = 0;i < (int)crates.size(); i++) {
    pref_min[i] = pref_max[i] = crates[i].first;
    if(i > 0) {
      pref_max[i] = max(pref_max[i], pref_max[i - 1]);
      pref_min[i] = min(pref_min[i], pref_min[i - 1]);
    }
  }

  for(int i = (int)crates.size() - 1;i >= 0;i--) {
    suff_min[i] = suff_max[i] = crates[i].first;
    if(i + 1 < (int)crates.size()) {
      suff_min[i] = min(suff_min[i + 1], suff_min[i]);
      suff_max[i] = max(suff_max[i + 1], suff_max[i]);
    }
  }

  int ans = CAP_MAX * 2;

  for(int i = 0;i <= (int)crates.size();i++){
    int fst = (i == 0 ? 0:pref_max[i - 1] - pref_min[i - 1]);
    int snd = (i == (int)crates.size() ? 0:suff_max[i] - suff_min[i]);

    ans = min(ans, fst + snd);
  }

  printf("%d\n", ans);

  return 0;
}
